package business;

public enum SimState {
	READY,
	SUSPENDED,
	STOPPED,
	RUNNING;
}
